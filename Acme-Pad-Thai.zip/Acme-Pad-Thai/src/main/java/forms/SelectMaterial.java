package forms;


public class SelectMaterial {
	
	public SelectMaterial(){
		super();
	}

	private int selected;
	
	public int getSelected() {
		return selected;
	}

	public void setSelected(int selected) {
		this.selected = selected;
	}

}
